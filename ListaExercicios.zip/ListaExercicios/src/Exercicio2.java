/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Exercicio2 {
    public static void main (String [] args){
        int anoDeNascimento = 2007;
        int anoAtual = 2025;
        int sub = anoAtual-anoDeNascimento;
        
        if(sub>=18){
            System.out.println("Maior de idade");
        }
        else{
            System.out.println("Menor de idade");
        }
    }
    
}
