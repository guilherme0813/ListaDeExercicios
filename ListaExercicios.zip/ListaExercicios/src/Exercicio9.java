/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Exercicio9 {
    public static void main (String [] args){
        
        double valorCompra = 90.00;
        double desc10 = valorCompra - (valorCompra*10/100);
        double desc5 = valorCompra - (valorCompra*5/100);
        
        if(valorCompra>100){
            System.out.println("Valor final da compra e " + desc10);
        }
        
        else{
            System.out.println("Valor final da compra e " + desc5);
        }
    }
    
}
