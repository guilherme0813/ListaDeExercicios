/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Exercicio11 {
    public static void main (String [] args){
        
        int lado1 = 5;
        int lado2 = 5;
        int lado3 = 5;
        
        if(lado1==lado2 && lado1==lado2 && lado2==lado3){
            
            System.out.println("Triangulo Equilatero");
        }
        else if(lado2!=lado3 && lado2!=lado1){
            
            System.out.println("Triangulo Escaleno");
        }
        else {
            System.out.println("Triangulo Isosceles");
        }
    }
    
}
