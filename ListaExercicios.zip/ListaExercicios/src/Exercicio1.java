/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Exercicio1 {
    public static void main (String [] args){
        double  numero1 = 3.0;
        double numero2 = 3.0;
        double numero3 = 3.0;
        double media = (numero1+numero2+numero3)/3;
        
        if(media>=7){
            System.out.println("Aprovado");
        }
        else{
            System.out.println("Reprovado");
        }
        
        
    }
    
}
