/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Exercicio8 {
    
    public static void main (String [] args){
        
        int dia = 21;
        int mes = 10 ;
        if (dia >= 22 && mes == 12 || dia<= 20 && mes==1){
        System.out.println("Capricórnio");
            }else if (dia >= 32  ||  mes >= 13){
                System.out.println("Data invalida");
            }else if (dia >= 21 && mes == 1 || dia<= 18 && mes==2){
             System.out.println("Aquário");
            }else if (dia >= 19 && mes == 2 || dia<= 20 && mes==3){
             System.out.println("Peixes");
            }else if (dia >= 21 && mes == 3 || dia<= 20 && mes==4){
             System.out.println("Ariés");
            }else if (dia >= 21 && mes == 4 || dia<= 20 && mes==5){
             System.out.println("Touro");
            }else if (dia >= 21 && mes == 5 || dia<= 20 && mes==6){
             System.out.println("Gêmeos");
            }else if (dia >= 21 && mes == 6 || dia<= 22 && mes==7){
             System.out.println("Câncer");
            }else if (dia >= 23 && mes == 7 || dia<= 22 && mes==8){
             System.out.println("Leão");
            }else if (dia >= 23 && mes == 8 || dia<= 22 && mes==9){
             System.out.println("Virgem");
            }else if (dia >= 23 && mes == 9|| dia<= 22 && mes==10){
             System.out.println("Libra");
            }else if (dia >= 23 && mes == 10|| dia<= 21 && mes==11){
             System.out.println("Escorpião");
            }else if (dia >= 22 && mes == 11 || dia<= 20 && mes==12){
             System.out.println("Sargitário");


            }

    }

}
