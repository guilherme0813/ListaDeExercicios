/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Exercicio17 {
    public static void main (String [] args){
        int ano = 2025;
        
        
        if(ano%4==0 && ano%100!=0){
            System.out.println("É um ano bissexto");
        }
        else{
            System.out.println("Não é um ano bissexto");
        }
    }
    
}
