/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Exercicio14 {
    public static void main (String [] args){
        
        int idade = 15;
        
        if(idade>=18){
            System.out.println("Voce deve votar");
        }
        else if(idade>=16){
            System.out.println("Voce pode votar");
        }
        else{
            System.out.println("Voce não pode votar");
        }
    }
    
}
