/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Exercicio10 {
    public static void main (String [] args){
        
        double peso = 60.0;
        double altura = 1.70;
        double imc = peso / (altura*altura);
        
        if(imc>=18.9 && imc<=24.9){
            
            System.out.println("Peso normal");
    }
        else if(imc>24.9 && imc<=29.9){
            
            System.out.println("Sobrepeso");
    }
        else if(imc>29.9){
            
            System.out.println("Obesidade");
        }
        else {
            
            System.out.println("Abaixo do peso");
        }
    }
    
}
