/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Exercicio15 {
    public static void main (String [] args){
        
        int numero = 1;
        String seg = "segunda-feira";
        String ter = "terça-feira";
        String qua = "quarta-feira";
        String qui = "quinta-feira";
        String sex = "sexta-feira";
        String sab = "sabado";
        String dom = "domingo";
        
        if(numero==1){
            System.out.println(seg);
        }
        else if(numero==2){
            System.out.println(ter);
        }
        else if(numero==3){
            System.out.println(qua);
        }
        else if(numero==4){
            System.out.println(qui);
        }
        else if(numero==5){
            System.out.println(sex);
        }
        else if(numero==6){
            System.out.println(sab);
        }
        else if(numero==7){
            System.out.println(dom);
        }
    }
    
}
