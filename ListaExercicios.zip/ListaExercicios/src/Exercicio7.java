/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Exercicio7 {
    public static void main (String [] args){
        
        int numero = 11;
        
        if(numero>10 && numero<20){
            System.out.println("Numero dentro do intervalo");
        }
        
        else {
            System.out.println("Numero fora do intervalo");
        }
        
    }
    
}
