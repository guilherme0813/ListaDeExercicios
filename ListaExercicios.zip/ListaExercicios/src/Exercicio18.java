/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Exercicio18 {
    public static void main (String [] args){
        
        double velocidade = 135.00;
        double multa = (velocidade-120.0)*10;
        
        if(velocidade>120){
            System.out.println("Velocidade acima do limite e pagara R$" + multa + " de multa");
        }
        else{
            System.out.println("Velocidade dentro do limite");
        }
    }
    
}
