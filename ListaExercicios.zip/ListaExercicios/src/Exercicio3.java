/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Exercicio3 {
    public static void main (String [] args){
        int numero = 2;
        
        if(numero>0){
            System.out.println("Positivo");
        }
        else if(numero==0){
            System.out.println("Zero");
        }
        else{
            System.out.println("Negativo");
        }
    }
    
}
