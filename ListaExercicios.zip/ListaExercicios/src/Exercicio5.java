/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Exercicio5 {
    public static void main (String [] args){
        
        int numero = 10;
        
        if(numero%5==0 && numero%3==0){
            System.out.println("Divisivel por 5 e 3");
        }
        else{
            System.out.println("Não é divisivel por 5 e 3");
        }
    }
    
}
