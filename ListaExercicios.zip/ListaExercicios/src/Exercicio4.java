/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Exercicio4 {
    public static void main (String [] args){
        int numero = 5;
        
        if(numero%2==0){
            System.out.println("Par");
        }
        else{
            System.out.println("Impar");
        }
    }
    
}
