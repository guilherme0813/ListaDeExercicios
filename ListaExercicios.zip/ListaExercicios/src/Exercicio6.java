/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Exercicio6 {
    public static void main (String [] args){
        int nota = 5;
        
        if(nota>=7){
            System.out.println("Aprovado");
        }
        else if(nota>=5){
            System.out.println("Recuperação");
        }
        else{
            System.out.println("Reprovado");
        }
    }
    
}
