/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Exercicio16 {
    public static void main (String [] args){
        int num1 = 5;
        int num2 = 5;
        
        if(num1>num2){
            System.out.println(num1 + " é maior que " + num2 + " e são numeros diferentes ");
        }
        else if(num1==num2){
            System.out.println(num1 + " e " + num2 + " são numeros igual ");
        }
        else{
            System.out.println(num1 + " é menor que " + num2 + " e são numeros diferentes ");
        }
    }
    
}
