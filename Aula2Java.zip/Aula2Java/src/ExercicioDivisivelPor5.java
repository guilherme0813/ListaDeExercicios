/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class ExercicioDivisivelPor5 {
    public static void main (String [] args){
        int numero = 10;
        
        if(numero%5==0){
            System.out.println("Divisivel por 5");
        }
        else{
            System.out.println("Não divisivel por 5");
        }
    }
    
}
