/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class ExercicioPositivo {
    public static void main (String [] args){
        
        int numero = 0;
        
        if(numero<0){
            System.out.println("Negativo");
        }
        else{
            System.out.println("Positivo");
        }
        
    }
    
}
