/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class MaiorOuMenor {
    public static void main (String [] args){
        
        //entrada
        int idade = 17;
        
        //processamento
        if (idade>=18) {
            System.out.println("Você é maior de idade");   
        } 
        
        else {
            System.out.println("Você é menor de idade");
        }
        
        
    }
}
    

